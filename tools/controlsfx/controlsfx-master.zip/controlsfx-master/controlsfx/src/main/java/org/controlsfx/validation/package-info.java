/**
 * A package containing validation-related API (that is, API to allow for developers
 * to easily validate user input, and to provide visual feedback on the results).
 */
package org.controlsfx.validation;